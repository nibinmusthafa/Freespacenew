

export const environment = {

  production: true,
  baseUrl: "http://13.127.161.51:8000/"

};
