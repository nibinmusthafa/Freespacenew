export interface leadremarks{
    id:number,
    lead_id:number,
    remark_data:string,
    datetime:Date,
    user_id:number,
}