export interface Leads{
    user:number;
    category:number;
    subcategory:number;
    name:string;
    leadsource:number;
    customer:number;
    description:string;
    renovation:string;
    units:number;
    status_value:number;
}