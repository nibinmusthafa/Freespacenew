export interface states{
    id:number;
    state_name:string;

}