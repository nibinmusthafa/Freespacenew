export interface icountry{
    id:number;
    country_name:string;

}