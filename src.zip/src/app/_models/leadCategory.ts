export interface LeadCategory{
    lead_id:number,
    category_id:number,
    units:number,
    subcat:string
}