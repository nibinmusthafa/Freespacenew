export interface files{
    id:number,
    file_name:string,
    date:Date,
    user_id:number,
    lead_id:number,
    url:string,
    name:string,
}